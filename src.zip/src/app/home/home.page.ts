import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { LoadingController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import {Md5} from 'ts-md5';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  
  url="https://ppa.2pisys.com";
  dataUrl=localStorage.getItem('url');
  datapass: any={"base64encodedimage":"./assets/image/no_logo.png"};
  authid="PXpv2YWV41L223hGDuXY";
  clientid="ppa";
  registerForm: FormGroup;
  submitted=false;

  constructor(public http: HttpClient,private formBuilder: FormBuilder,public loadingController: LoadingController,public toastController: ToastController,private router: Router){}

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      userid: ['', Validators.required],
      password: ['', Validators.required]
  });

  this.versionToastFunction();

  if(localStorage.getItem('url') != null || localStorage.length != 0)
    {
      this.dataUrl=localStorage.getItem('url');       
    }
    else
    {
      localStorage.setItem('url',this.url);
    }

    if(localStorage.getItem('authid') != null)
    {
      this.authid=localStorage.getItem('authid');       
    }
    else
    {
      localStorage.setItem('authid',this.authid);
    }

    if(localStorage.getItem('clientid') != null)
    {
      this.clientid=localStorage.getItem('clientid');       
    }
    else
    {
      localStorage.setItem('clientid',this.clientid);
    }

    if(localStorage.getItem('userid') != null && localStorage.getItem('password') != null)
    {
      this.router.navigate(["Widgets"]);   
    }
    else
    {
      this.router.navigate(["home"]);
    }


    const headers = { 'auth-id': localStorage.getItem('authid'), 'client-id': localStorage.getItem('clientid') }

    this.http.get<any>(this.dataUrl+'/api/custicon',{headers}).subscribe({
      next: async data => {
        this.datapass=data.message[0]; 
        this.datapass.base64encodedimage="data:image/png;base64,"+data.message[0].base64encodedimage;
        localStorage.setItem('brandImage',this.datapass.base64encodedimage);    
      },
      error: errordata => {
        if(errordata.error.message){
        this.toastfunction(errordata.error.message,"danger");  
        }
        else{
          this.toastfunction("Invalid Company Url, Please Check in Home page","danger");
        }
      }
    });

  }

  
   // convenience getter for easy access to form fields
   get f() { return this.registerForm.controls; }

  textChanged(obj)
  { 
    localStorage.setItem('url', obj);
  }
  
  
  onClickMe(obj) {
    this.router.navigate([obj]);
  }



  // async submitData()
  // {   
  //   this.submitted=true;
  //   const loading = await this.loadingController.create({
  //     cssClass: 'my-custom-class',
  //     message: 'Please wait...',
  //     spinner:'dots'
  //   });  
  //   await loading.present();

  //   if (this.registerForm.invalid) {
  //     return;
  //   }
  //   else
  //   {

  //     const headers = { 
  //       'auth-id': localStorage.getItem('authid'), 
  //       'client-id': localStorage.getItem('clientid'),
  //       'user': this.registerForm.value.userid,
  //       'password':Md5.hashStr(this.registerForm.value.password) }

  //     this.http.get<any>(this.dataUrl+"/api/reportlinks/"+this.registerForm.value.userid,{headers}).subscribe({
  //       next: async data => {
  //         this.router.navigate(["Widgets"]);
  //         localStorage.setItem('userid',this.registerForm.value.userid);
  //         localStorage.setItem('password',Md5.hashStr(this.registerForm.value.password));
  //         this.setStorage();
  //         loading.dismiss();          
  //       },
  //       error: errordata => {
  //         if(errordata.error.message){
  //           loading.dismiss();         
  //           this.toastfunction(errordata.error.message,"danger");  
  //           }
  //           else{
  //             loading.dismiss();  
  //             this.toastfunction("Invalid Company Url, Please Check in Home page","danger");
  //           }
  //       }
  //     });

  //   } 

  // }

  async submitData()
  {   
    this.submitted=true;
    const loading = await this.loadingController.create({
      cssClass: 'my-custom-class',
      message: 'Please wait...',
      spinner:'dots'
    });  
    await loading.present();

    if (this.registerForm.invalid) {
      return;
    }
    else
    {

      const headers = { 
        'auth-id': localStorage.getItem('authid'), 
        'client-id': localStorage.getItem('clientid'),
        'user': this.registerForm.value.userid,
        'password':Md5.hashStr(this.registerForm.value.password) }

      this.http.get<any>(this.dataUrl+"/api/userlogin/"+this.registerForm.value.userid,{headers}).subscribe({
        next: async data => {
          this.router.navigate(["Widgets"]);
          localStorage.setItem('userid',this.registerForm.value.userid);
          localStorage.setItem('password',Md5.hashStr(this.registerForm.value.password));
          this.setStorage();
          loading.dismiss();          
        },
        error: errordata => {
          if(errordata.error.message){
            loading.dismiss();         
            this.toastfunction(errordata.error.message,"danger");  
            }
            else{
              loading.dismiss();  
              this.toastfunction("Invalid Company Url, Please Check in Home page","danger");
            }
        }
      });

    } 

  }


  expiryDate;
  setStorage() {
    let date = new Date();
    this.expiryDate= date.setDate(date.getDate() + 1); 
    localStorage.setItem("your-data-key", this.expiryDate.toString());
  }
  
  
  async toastfunction(msg,colour)
  {
    const toast = await this.toastController.create({
      message: msg,
      duration: 2000,
      position: 'bottom',
      animated:true,
      color:colour
    });

    toast.present();
  }

  refresher()
  {
   this.ngOnInit();
  }
  
  async versionToastFunction()
  {
    const toast2 = await this.toastController.create({
      header:"Update required:",
      message: "New version is available in store, Please install.",
      position: 'middle',
      animated:true,
      color:"tertiary",
      cssClass:"my-custom-class",
      buttons: [
       {
          side: 'end',
          text: 'Close',
          role: 'cancel',
          icon:'close',
          handler: () => {
            console.log('Close clicked');
          }
        }
      ]
    });

    toast2.present();
  }

}
