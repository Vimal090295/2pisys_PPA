import { CalenderplanningPipe } from './calenderplanning.pipe';

describe('CalenderplanningPipe', () => {
  it('create an instance', () => {
    const pipe = new CalenderplanningPipe();
    expect(pipe).toBeTruthy();
  });
});
