import { DispatchplanningPipe } from './dispatchplanning.pipe';

describe('DispatchplanningPipe', () => {
  it('create an instance', () => {
    const pipe = new DispatchplanningPipe();
    expect(pipe).toBeTruthy();
  });
});
