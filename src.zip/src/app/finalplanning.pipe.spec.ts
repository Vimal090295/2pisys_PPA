import { FinalplanningPipe } from './finalplanning.pipe';

describe('FinalplanningPipe', () => {
  it('create an instance', () => {
    const pipe = new FinalplanningPipe();
    expect(pipe).toBeTruthy();
  });
});
